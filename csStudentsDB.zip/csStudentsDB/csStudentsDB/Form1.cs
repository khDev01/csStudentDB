﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;//added
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;//added

namespace csStudentsDB
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

        }

        /*
         * add
         * display
         * delete
         * change/amend
         * 
        */



        OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OLEDB.12.0;Data Source=C:\\Users\\Tanveer Hussain\\Documents\\Kasim\\1Projects\\csStudentsDB\\students.accdb");

        //add
        private void btnSubmit_Click(object sender, EventArgs e)
        {
            string FirstName = textBox1.Text;
            string LastName = textBox2.Text;

            OleDbCommand cmd = con.CreateCommand();
            con.Open();
            cmd.CommandText = "Insert into Student(FirstName,LastName)Values('" + FirstName + "','" + LastName + "')";
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
            MessageBox.Show("Record Submitted", "Congrats");
            con.Close();
        }

        //display
        private void btnShowData_Click(object sender, EventArgs e)
        {
            if (con.State != ConnectionState.Open)
            {
                con.Open();
            }
            OleDbCommand cmd = new OleDbCommand("SELECT * FROM Student", con);
            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());
            dataGridView1.DataSource = dt;
            dataGridView1.Columns["ID"].DisplayIndex = 0;
            dataGridView1.Columns["FirstName"].DisplayIndex = 1;
            dataGridView1.Columns["LastName"].DisplayIndex = 2;

            dt.Load(cmd.ExecuteReader());
            dataGridView2.DataSource = dt;
            dataGridView2.Columns["ID"].DisplayIndex = 0;
            dataGridView2.Columns["FirstName"].DisplayIndex = 1;
            dataGridView2.Columns["LastName"].DisplayIndex = 2;
            con.Close();

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'studentsDataSet.Student' table. You can move, or remove it, as needed.
            this.studentTableAdapter.Fill(this.studentsDataSet.Student);
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView3_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            switch (dataGridView2.Columns[e.ColumnIndex].Name)
            {
                case "Delete":
                    if (con.State != ConnectionState.Open)
                    {
                        con.Open();
                    }

                    OleDbCommand cmd2 = new OleDbCommand("SELECT * FROM Student", con);
                    DataTable dt = new DataTable();
                    dt.Load(cmd2.ExecuteReader());
                    dataGridView2.DataSource = dt;
                    dataGridView2.Columns["ID"].DisplayIndex = 0;
                    dataGridView2.Columns["FirstName"].DisplayIndex = 1;
                    dataGridView2.Columns["LastName"].DisplayIndex = 2;

                    OleDbCommand deleteCmd = new OleDbCommand("delete from Student where ID = @codeEmp", con);
                    deleteCmd.Parameters.AddWithValue("codeEmp", dataGridView2.CurrentRow.Cells["ID"].Value.ToString());
                    DialogResult result = MessageBox.Show("DELETE person?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (result == DialogResult.Yes)
                    {
                        deleteCmd.ExecuteNonQuery();
                        MessageBox.Show("Successeful delete");
                    }

                    con.Close();

                    break;
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {

        }
    }
}
